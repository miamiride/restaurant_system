// Restaurant Project in C++.
 
#include<iostream>
#include<conio.h>//used to run input /output functions mostly for MS DOS compilers
#include<stdlib.h>//used in exit () functions
using namespace std;
main()//os cmds
{
	int p_p=0,p_b=0,p_s=0,p_i=0,p_c=0;
	//p=quantity/number
	int s_p=0,s_b=0,s_s=0,s_i=0,s_c=0;
	//s=sales
	int p=0,b=0,s=0,i=0,c=0;
	//items price
	int choice,q;
	cout<<"\n\t\t\tPurchase Items";
	cout<<"\n\n Number of Pizza : ";
	cin>>p_p;
	cout<<"\n\n Number of Burger : ";
	cin>>p_b;
	cout<<"\n\n Number of Sandwich : ";
	cin>>p_s;
	cout<<"\n\n Number of Ice-Cream : ";
	cin>>p_i;
	cout<<"\n\n Number of Cake : ";
	cin>>p_c;
	p://goto declaration sn
	system("cls");// system cmd runs the systems cmds  cls  clear  output screen
	cout<<"\n\t\t\tControl Panel";
	cout<<"\n\n 1. Pizza";
	cout<<"\n 2. Burger";
	cout<<"\n 3. Sandwich";
	cout<<"\n 4. Ice-Cream";
	cout<<"\n 5. Cake";
	cout<<"\n 6. Details";
	cout<<"\n 7. Exit";
	cout<<"\n\n Enter Your Choice : ";
	cin>>choice;
	cout<<"\n\n Do You Want to enter another choice (yes,no) : ";
			 string y;
			cin>>y;
		if(y=="yes"|| y=="YES"){
		goto p;
			}
			else{
				
			}
			
			
	
	switch(choice)
	{
		case 1:
			cout<<"\n\n Enter Pizza Quantity : ";
			
			cin>>q;
			if(p_p-s_p >= q)//total pizza number minus sales >=q then make a sale otherwise no pizza sale
			{
				s_p += q;//sales + quantity  purchased
				p += q*700; //price = price+(quantity*price) as..p=0+(2*700)
			//	cout<<"\n\t"<<"total price is "<<p;
				cout<<"\n\n\n\t\t\t"<<q<<" Pizza Sales Thank You!!!";
					
			}
			else
			cout<<"\n\n\n\t\t\tSorry "<<p_p-s_p<<" Pizza Remaining in Resturent...";
			break;
		case 2:
			cout<<"\n\n Enter Burger Quantity : ";
			cin>>q;
			if(p_b-s_b >= q)
			{
				s_b += q;
				b += q*100;
				cout<<"\n\n\n\t\t\t"<<q<<" Burger Sales Thank You!!!";	
			}
			else
			cout<<"\n\n\n\t\t\tSorry "<<p_b-s_b<<" Burger Remaining in Resturent...";
			break;
		case 3:
			cout<<"\n\n Enter Sandwich Quantity : ";
			cin>>q;
			if(p_s-s_s >= q)
			{
				s_s += q;
				s += q*150;
				cout<<"\n\n\n\t\t\t"<<q<<" Sandwich Sales Thank You!!!";	
			}
			else
			cout<<"\n\n\n\t\t\tSorry "<<p_s-s_s<<" Sandwich Remaining in Resturent...";
			break;
		case 4:
			cout<<"\n\n Enter Ice-Cream Quantity : ";
			cin>>q;
			if(p_i-s_i >= q)
			{
				s_i += q;
				i += q*200;
				cout<<"\n\n\n\t\t\t"<<q<<" Ice-Cream Sales Thank You!!!";	
			}
			else
			cout<<"\n\n\n\t\t\tSorry "<<p_i-s_i<<" Ice-Cream Remaining in Resturent...";
			break;
		case 5:
			cout<<"\n\n Enter Cake Quantity : ";
			cin>>q;
			if(p_c-s_c >= q)
			{
				s_c += q;
				c += q*500;
				cout<<"\n\n\n\t\t\t"<<q<<" Cake Sales Thank You!!!";	
			}
			else
			cout<<"\n\n\n\t\t\tSorry "<<p_c-s_c<<" Cake Remaining in Resturent...";
			break;
		case 6:
			
				long userId; //for user id of administrator
      		
			d:	
			cout<<"\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t---------------------";
			cout<<"\n\t\t\t\t\t\t\tEnter Login Id = ";
			cin>>userId;
			cout<<"\t\t\t\t\t\t\t---------------------";
			if(userId!=1353)  
			{
				cout<<"\nDon't try to be smart.....Enter correct id\n";
				goto d;
			}
			if (userId==1353){
			
			 
      				cout<<"\n\n\t\t\t\t\t\t\tAccess Granted. Welcome to our system\n\n\n";
      				system("PAUSE");//allow user to press any key to continue
      				system("CLS") ;
				      }
				
                        else {
			
				goto d;
				}

			system("cls");
			cout<<"\n\t\t\tDetails Panel";
			cout<<"\n\n Purchase Pizza Quantity : "<<p_p;
			cout<<"\n Sales Pizza Quantity : "<<s_p;
			cout<<"\n Remaining Pizza Quantity : "<<p_p-s_p;//total number - sales number
			cout<<"\n Total Pizza Price in a Day : "<<p;
			cout<<"\n\n Purchase Burger Quantity : "<<p_b;
			cout<<"\n Sales Burger Quantity : "<<s_b;
			cout<<"\n Remaining Burger Quantity : "<<p_b-s_b;
			cout<<"\n Total Burger Price in a Day : "<<b;
			cout<<"\n\n Purchase Sandwich Quantity : "<<p_s;
			cout<<"\n Sales Sandwich Quantity : "<<s_s;
			cout<<"\n Remaining Sandwich Quantity : "<<p_s-s_s;
			cout<<"\n Total Sandwich Price in a Day : "<<s;
			cout<<"\n\n Purchase Ice-Cream Quantity : "<<p_i;
			cout<<"\n Sales Ice-Cream Quantity : "<<s_i;
			cout<<"\n Remaining Ice-Cream Quantity : "<<p_i-s_i;
			cout<<"\n Total Ice-Cream Price in a Day : "<<i;
			cout<<"\n\n Purchase Cake Quantity : "<<p_c;
			cout<<"\n Sales Cake Quantity : "<<s_c;
			cout<<"\n Remaining Cake Quantity : "<<p_c-s_c;
			cout<<"\n Total Cake Price in a Day : "<<c;
			cout<<"\n\n\n Total Day Price : "<<p+b+s+i+c;//pizza+burger+sandwich+icecream+cake 
			break;
		case 7:
			
			
			exit(0);//shows successful termination
		default:
			cout<<"\n\n Invalid Value...Please Try Again...";
			goto p;
			
			
			
			
	}
	
	getch();//read characters from the keyboard also holds screen until the user enters any character.otherwise the screen gonna close with 
	        //fraction of a second
	goto p;//goto calling sn
	//jumps to p coz its defined/once the transaction is done it refreshes from p
	     //uconditional jump sn allows program execution to jump to a specified locationwithin the function
} 

